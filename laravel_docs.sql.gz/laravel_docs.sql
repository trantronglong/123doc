-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2016 at 09:42 AM
-- Server version: 5.5.45
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel_docs`
--

-- --------------------------------------------------------

--
-- Table structure for table `doc_articles`
--

CREATE TABLE `doc_articles` (
  `id` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_kewords` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doc_articles`
--

INSERT INTO `doc_articles` (`id`, `slug`, `title`, `category`, `description`, `content`, `meta_kewords`, `meta_description`, `updated_at`, `status`, `created_at`) VALUES
(1, 'gioi-thieu-ve-nha-sach-online', 'Giới thiệu về Nhà sách online', 22, 'giới thiệu', '<p dir="ltr">Xuất ph&aacute;t từ &yacute; tưởng tạo cộng đồng kiếm tiền online bằng t&agrave;i liệu hiệu quả nhất, uy t&iacute;n cao nhất. Mong muốn mang lại cho cộng đồng x&atilde; hội một nguồn t&agrave;i nguy&ecirc;n tri thức qu&yacute; b&aacute;u, phong ph&uacute;, đa dạng, gi&agrave;u gi&aacute; trị đồng thời mong muốn tạo điều kiện cho cho c&aacute;c users c&oacute; th&ecirc;m thu nhập. Ch&iacute;nh v&igrave; vậy <strong>123doc.org</strong> ra đời nhằm đ&aacute;p ứng nhu cầu chia sẻ t&agrave;i liệu chất lượng v&agrave; kiếm tiền online.</p>\r\n<p dir="ltr">Sau hơn một năm ra đời, 123doc đ&atilde; từng bước khẳng định vị tr&iacute; của m&igrave;nh trong lĩnh vực t&agrave;i liệu v&agrave; kinh doanh online. T&iacute;nh đến thời điểm th&aacute;ng 5/2014; 123doc vượt mốc 100.000 lượt truy cập mỗi ng&agrave;y, sở hữu <strong>2.000.000</strong> th&agrave;nh vi&ecirc;n đăng k&yacute;, lọt v&agrave;o <strong>top 200</strong> c&aacute;c website phố biến nhất tại Việt Nam, tỷ lệ t&igrave;m kiếm thuộc top 3 Google. Nhận được danh hiệu do cộng đồng b&igrave;nh chọn l&agrave; website kiếm tiền online hiệu quả v&agrave; uy t&iacute;n nhất.</p>', '', '', '2016-04-17 20:42:55', 1, '2016-04-11 09:36:53'),
(2, 'dieu-khoan-su-dung', 'Điều khoản sử dụng', 22, 'Điều khoản sử dụng', '<p dir="ltr"><strong>Sửa đổi, bổ sung Thỏa thuận sử dụng dịch vụ</strong></p>\r\n<p dir="ltr"><em><strong>1. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Chấp nhận c&aacute;c điều khoản thỏa thuận sử dụng </strong></em></p>\r\n<p dir="ltr">Ch&agrave;o mừng bạn đến với 123doc.org! 123doc.org cung cấp Dịch Vụ theo c&aacute;c &ldquo;Điều Khoản Thỏa Thuận về Sử Dụng Dịch Vụ&rdquo; (sau đ&acirc;y được gọi tắt l&agrave;"ĐKTTSDDV"). Việc bạn sử dụng hoặc đăng k&yacute; sử dụng c&aacute;c dịch vụ của123doc.org đồng nghĩa với việc bạn đ&atilde; đồng &yacute; với c&aacute;c điều khoản của Thỏa thuận sửdụng n&agrave;y v&agrave; trở th&agrave;nh Th&agrave;nh vi&ecirc;n của 123doc.org. Nếu bạn kh&ocirc;ng đồng &yacute; vui l&ograve;ng kh&ocirc;ng sử dụng hoặc đăng k&yacute; sử dụng c&aacute;c dịch vụ được cung cấp bởi 123doc.org.123doc.org c&oacute; thể thay đổi, điều chỉnh ĐKTTSDDV theo quyết định của m&igrave;nh theo từng thời điểm m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho Th&agrave;nh vi&ecirc;n. Th&agrave;nh vi&ecirc;n đồng &yacute; rằng nếu Th&agrave;nh vi&ecirc;n tiếp tục sử dụng Dịch Vụ sau khi ĐKTTSDDV được cập nhật, việc đ&oacute; c&oacute; nghĩa l&agrave; Th&agrave;nh vi&ecirc;n đ&atilde; chấp nhận v&agrave; đồng &yacute; tu&acirc;n theo bản ĐKTTSDDV đ&atilde; được cập nhật. Th&agrave;nh vi&ecirc;n c&oacute; thể xem bản ĐKTTSDDV mới nhất v&agrave;o bất cứ thời điểm n&agrave;o tại đ&acirc;y.</p>\r\n<p dir="ltr">Ngo&agrave;i ra, khi sử dụng c&aacute;c Dịch Vụ cụ thể thuộc sở hữu hoặc điều h&agrave;nh bởi 123doc.org, Th&agrave;nh vi&ecirc;n sẽ phải thực hiện theo đ&uacute;ng c&aacute;c chỉ dẫn được ni&ecirc;m yết hoặc c&aacute;c quy định &aacute;p dụng cho c&aacute;c dịch vụ đ&oacute; c&oacute; thể được ni&ecirc;m yết theo từng thời điểm. Tất cả c&aacute;c chỉ dẫn hoặc quy định đ&oacute; được đưa v&agrave;o bản ĐKTTSDDV n&agrave;y dưới dạng tham chiếu. Trong đa số c&aacute;c trường hợp, c&aacute;c chỉ dẫn v&agrave; quy định l&agrave; cụ thể cho từng phần ri&ecirc;ng biệt v&agrave; sẽ gi&uacute;p Th&agrave;nh vi&ecirc;n &aacute;p dụng ĐKTTSDDV cho phần ri&ecirc;ng biệt đ&oacute;, nhưng trong trường hợp c&oacute; sự kh&ocirc;ng thống nhất giữa ĐKTTSDDV với bất kỳ quy định hoặc chỉ dẫn n&agrave;o, bản ĐKTTSDDV sẽ c&oacute; hiệu lực cấp dụng.</p>', '', '', '2016-04-17 20:42:54', 1, '2016-04-17 19:35:07'),
(3, 'cau-hoi-thuong-gap', 'Câu hỏi thường gặp', 22, 'Câu hỏi thường gặp', '<p dir="ltr"><strong><em>1. L&agrave;m sao để đăng k&yacute; trở th&agrave;nh th&agrave;nh vi&ecirc;n của 123doc.org</em></strong></p>\r\n<p dir="ltr">C&aacute;ch 1: Bạn c&oacute; thể click v&agrave;o đăng nhập<a href="https://id.vatgia.com/dang-nhap/?acc=0&amp;service=123doc&amp;_cont=http%3A%2F%2F123doc.org%2Ftrang-chu.htm" target="_blank"> tại đ&acirc;y</a></p>\r\n<p dir="ltr">- Bạn c&oacute; thể lựa chọ đăng nhập qua facebook hoặc đăng nhập bằng gmail bằng c&aacute;ch click v&agrave;o &ocirc; biểu tượng tương ứng.</p>\r\n<p dir="ltr"><img src="http://media.store123doc.com:8080//images/news/20150820140815_65108.png" alt="" border="0" /></p>\r\n<p dir="ltr">C&aacute;ch 2: Bạn c&oacute; thể sử dụng t&agrave;i khoản của id vật gi&aacute; để đăng nhập v&agrave;o t&agrave;i khoản của 123doc.org (bạn c&oacute; thể sử dụng t&agrave;i khoản của 123doc.org để đăng nhập với c&aacute;c website tr&ecirc;n hệ thống cảu vật gi&aacute;: vatgia.com; baokim.vn; cucre.vn; nhanh.vn;siki.vn; mytour.vn; 123tv.vn; pub.vn; iki.vn; myad.vn,....)</p>', '', '', '2016-04-17 20:42:52', 1, '2016-04-17 19:35:43'),
(4, 'chinh-sach-bao-mat-thong-tin', 'Chính sách bảo mật thông tin', 22, 'Chính sách bảo mật thông tin', '<p dir="ltr">123doc.org cam kết sẽ bảo mật những th&ocirc;ng tin mang t&iacute;nh ri&ecirc;ng tư của kh&aacute;ch h&agrave;ng. Th&agrave;nh vi&ecirc;n c&oacute; thể đọc bản <strong>&ldquo;Ch&iacute;nh s&aacute;ch bảo mật&rdquo; </strong>để hiểu hơn những cam kết m&agrave; Ban quản trị thực hiện, nhằm t&ocirc;n trọng v&agrave; bảo vệ quyền lời của người truy cập</p>\r\n<p dir="ltr"><strong><em>1. Th&ocirc;ng tin c&aacute;c nh&acirc;n</em></strong></p>\r\n<p dir="ltr">C&aacute;c th&ocirc;ng tin thu thập qua website 123doc.org sẽ được ch&uacute;ng t&ocirc;i</p>\r\n<ul>\r\n<li dir="ltr">\r\n<p dir="ltr">Hỗ trợ kh&aacute;ch h&agrave;ng khi c&oacute; mua t&agrave;i liệu tr&ecirc;n hệ thống 123doc.org</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Giải đ&aacute;p thắc mắc kh&aacute;ch h&agrave;ng</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Cung cấp cho bạn th&ocirc;ng tin mới nhất tr&ecirc;n website của 123doc</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">thực hiện c&aacute;c hoạt động quảng b&aacute;, event li&ecirc;n quan đến c&aacute;c sản phẩm v&agrave; dịch vủa của 123doc.org</p>\r\n</li>\r\n</ul>\r\n<p dir="ltr">Để truy cập v&agrave; sử dụng một số dịch vụ tại 123doc.org, th&agrave;nh vi&ecirc;n sẽ được y&ecirc;u cầu đăng k&yacute; với Ban quản trị th&ocirc;ng tin c&aacute; nh&acirc;n (Email, Họ t&ecirc;n, số điện thoại li&ecirc;n lạc,...) Mọi th&ocirc;ng tin khai b&aacute;o phải đảm bảo t&iacute;nh ch&iacute;nh x&aacute;c v&agrave; hợp ph&aacute;p. 123doc.org kh&ocirc;ng chịu mọi tr&aacute;ch nhiệm li&ecirc;n quan đến ph&aacute;p luật của th&ocirc;ng tin khai b&aacute;o.</p>\r\n<p dir="ltr">Ban quản trị cũng c&oacute; thể thu thập th&ocirc;ng tin về số lần viếng thăm, bao gồm số trang th&agrave;nh vi&ecirc;n xem, số links (li&ecirc;n kết) bạn click v&agrave; nhưng th&ocirc;ng tin kh&aacute;c li&ecirc;n quan đến việc kết nối đến 123doc.org. Ban quản trị cũng thu thập c&aacute;c th&ocirc;ng tin m&agrave; tr&igrave;nh duyệt web th&agrave;nh vi&ecirc;n sử dụng mỗi khi truy cập v&agrave;o website 123doc.org, bao gồm: địa chỉ IP, ng&ocirc;n ngữ sử dụng, thời gian,...</p>', '', '', '2016-04-17 20:42:50', 1, '2016-04-17 19:36:02'),
(5, 'ly-do-ban-dang-tai-lieu-tai-123docorg', 'Lý do bạn đăng tài liệu tại 123doc.org', 23, 'Lý do bạn đăng tài liệu tại 123doc.org', '<p dir="ltr">Chỉ một bước đơn giản bạn đ&atilde; c&oacute; thể đăng b&aacute;n t&agrave;i liệu của m&igrave;nh tr&ecirc;n 123doc.org</p>\r\n<p dir="ltr">H&atilde;y <a href="https://id.vatgia.com/dang-ky/?remember=1&amp;service=123doc&amp;_cont=http://123doc.org/home/idvg_return.php?url_back=L3RyYW5nLWNodS5odG0=">đăng k&yacute; th&agrave;nh vi&ecirc;n</a> v&agrave; <a href="http://upload.123doc.org/upload-tai-lieu.htm">UPLOAD</a> ngay h&ocirc;m nay</p>\r\n<p dir="ltr"><img src="https://lh4.googleusercontent.com/tjD14FzUIoEtONhA4IhhPiC5S6gIBbxn0wN6JE7r7GLGjGKoWO0jKBdfoPvZ1sLZZV0vEi2LM-UfUGIV6Q1DaKeOFtP5EL0S4ZhWD-hoHnuKCPlX7qufgn5KRJjOeRg6Jxvos8Az_uhPENAEig" alt="" width="261" height="61" /></p>\r\n<p dir="ltr">Mọi thắc mắc li&ecirc;n hệ: info@123doc.org</p>\r\n<ol>\r\n<li dir="ltr">\r\n<p dir="ltr">Gia tăng doanh thu từ t&agrave;i liệu của bạn</p>\r\n</li>\r\n</ol>\r\n<p>&nbsp;</p>\r\n<p dir="ltr">123doc sẽ chia sẻ doanh thu cho bạn khi bạn b&aacute;n th&agrave;nh c&ocirc;ng t&agrave;i liệu</p>\r\n<p dir="ltr"><img src="https://lh5.googleusercontent.com/UAag7UGVpvn5k_5gxtPUT6y2DiQa1_fIPTY4ZZmw1PvNH0SWftLIdSEXZ_sVRVETtrFwd1LBi20k0dexslUdS5dZHcPcKWmeTyTtjFrGmwL6Rz22UvnfTm0O3UCioan-QM6EQWrreuqo1-ydEQ" alt="" width="476" height="354" /></p>\r\n<p dir="ltr">VD: Bạn đặt gi&aacute; b&aacute;n 100.000VND/ t&agrave;i liệu &rarr; 1 lượt mua bạn sẽ nhận ngay 70.000 VND</p>', '', '', '2016-04-17 20:42:48', 1, '2016-04-17 19:36:39'),
(6, 'huong-dan-rut-tien-qua-tai-khoan-baokimvn', 'Hướng dẫn rút tiền qua tài khoản Baokim.vn', 23, 'Hướng dẫn rút tiền qua tài khoản Baokim.vn', '<div>Đăng nhập t&agrave;i khoản 123doc.org<br />- Click v&agrave;o biểu tượng setting (h&igrave;nh tr&ograve;n c&oacute; răng cưa) chọn r&uacute;t tiền<br />- Điền đầy đủ c&aacute;c th&ocirc;ng tin "R&uacute;t tiền về t&agrave;i khoản bảo kim"<br />&nbsp; &nbsp; &nbsp; + Số tiền r&uacute;t<br />&nbsp; &nbsp; &nbsp; + Số điện thoại<br />&nbsp; &nbsp; &nbsp; + M&atilde; x&aacute;c thực<br />- Click "R&uacute;t tiền"<br />- 123doc tiếp nhận thanh to&aacute;n cho kh&aacute;ch h&agrave;ng v&agrave;o <strong>5h chiều ng&agrave;y 1&nbsp;</strong>h&agrave;ng th&aacute;ng<br />\r\n<div><img src="http://media.store123doc.com:8080/images/news/20141113101106_70269.png" alt="" border="0" /></div>\r\n</div>\r\n<div>Sau khi x&aacute;c nhận số tiền cần thanh to&aacute;n, 123doc sẽ gửi tiền v&agrave;o t&agrave;i khoản Bảo Kim của bạn.&nbsp;</div>\r\n<div><em><strong>Ch&uacute; &yacute;:</strong></em></div>\r\n<div>- Số tiền tối thiểu được r&uacute;t khi b&aacute;n t&agrave;i liệu: 100.000 VND, chỉ r&uacute;t tiền th&ocirc;ng qua t&agrave;i khoản Bảo Kim.</div>\r\n<div><span style="font-family: Arial;">- Để đảm bảo quyền lợi của c&aacute;c bạn, c&aacute;c bạn phải điền th&ocirc;ng tin ch&iacute;nh x&aacute;c. 123doc sẽ căn cứ v&agrave; th&ocirc;ng tin c&aacute;c bạn đăng k&yacute; để thanh to&aacute;n tiền cho c&aacute;c bạn.</span></div>', '', '', '2016-04-17 20:42:46', 1, '2016-04-17 19:37:10'),
(7, 'dat-gia-ban-phu-hop-de-tang-doanh-thu-tu-ban-tai-lieu', 'Đặt giá bán phù hợp để tăng doanh thu từ bán tài liệu', 23, 'Đặt giá bán phù hợp để tăng doanh thu từ bán tài liệu', '<p dir="ltr">Xin ch&agrave;o c&aacute;c bạn th&agrave;nh vi&ecirc;n!</p>\r\n<p dir="ltr">Đ&atilde; bao giờ c&aacute;c bạn nghi ngờ thay đổi gi&aacute; b&aacute;n t&agrave;i liệu sẽ tăng được doanh thu?</p>\r\n<p dir="ltr">Nếu bạn đang nghi ngờ th&igrave; h&atilde;y đọc hết b&agrave;i viết chia sẻ dưới của admin, admin sẽ chia sẻ với c&aacute;c bạn một số điểm nhận biết để thay đổi gi&aacute; b&aacute;n t&agrave;i liệu v&agrave; tăng doanh thu b&aacute;n trong ngay th&aacute;ng đầu ti&ecirc;n. Những điểm nhận diện n&agrave;y do admin r&uacute;t ra từ th&oacute;i quen nạp tiền của kh&aacute;ch h&agrave;ng như:</p>\r\n<p><img src="http://i.piccy.info/i9/028895ba422e207fc112ae8ada4e78e9/1419335137/7480/837382/Icon_check.png" alt="" width="25" height="25" border="0" />Kh&aacute;ch h&agrave;ng c&oacute; th&oacute;i quen hay nạp thẻ 1 lần khi mua t&agrave;i liệu.<br /><img src="http://i.piccy.info/i9/028895ba422e207fc112ae8ada4e78e9/1419335137/7480/837382/Icon_check.png" alt="" width="25" height="25" border="0" />Đến 70% kh&aacute;ch h&agrave;ng nạp tiền chỉ để tải 1 t&agrave;i liệu, c&ograve;n lại l&agrave; 2 t&agrave;i liệu cho mỗi lần nạp tiền.<br /><img src="http://i.piccy.info/i9/028895ba422e207fc112ae8ada4e78e9/1419335137/7480/837382/Icon_check.png" alt="" width="25" height="25" border="0" />Kh&aacute;ch h&agrave;ng sử dụng thẻ C&agrave;o viễn th&ocirc;ng l&agrave; chủ yếu, đến 80% sản lượng.<br /><img src="http://i.piccy.info/i9/028895ba422e207fc112ae8ada4e78e9/1419335137/7480/837382/Icon_check.png" alt="" width="25" height="25" border="0" />35% kh&aacute;ch h&agrave;ng mua t&agrave;i liệu l&agrave; kh&ocirc;ng đăng nhập v&agrave; sử dụng thẻ c&agrave;o để tải về.<br /><img src="http://i.piccy.info/i9/028895ba422e207fc112ae8ada4e78e9/1419335137/7480/837382/Icon_check.png" alt="" width="25" height="25" border="0" />Tỷ lệ lượt tải tr&ecirc;n lượt xem cao hoặc thấp.</p>', '', '', '2016-04-17 20:42:42', 1, '2016-04-17 19:37:35'),
(8, 'chinh-sach-danh-cho-nguoi-ban', 'Chính sách dành cho người bán', 23, 'Chính sách dành cho người bán', '<p dir="ltr">123doc.org l&agrave; một giải ph&aacute;p cho bạn. Bởi đơn giản, 123doc.org l&agrave; một s&agrave;n giao dịch t&agrave;i liệu điển h&igrave;nh ở Việt Nam, đi ti&ecirc;n phong với c&ocirc;ng nghệ SEO v&agrave; c&aacute;c giải ph&aacute;p kinh doanh trực tuyến. B&agrave;i viết n&agrave;y hướng dẫn c&aacute;c kiếm tiền v&agrave; c&aacute;c ch&iacute;nh s&aacute;ch cho người b&aacute;n tr&ecirc;n 123doc, đ&acirc;y cũng l&agrave; h&igrave;nh thức l&agrave;m việc tự do hiệu quả, kiếm được nguồn thu nhập thu động c&ugrave;ng những đại gia trong ng&agrave;nh.</p>\r\n<p dir="ltr">Một số ch&iacute;nh s&aacute;ch 123doc.org hiện nay đang &aacute;p dụng cho người b&aacute;n t&agrave;i liệu.</p>\r\n<p dir="ltr"><em>1. Kiếm doanh thu từ việc b&aacute;n t&agrave;i liệu </em></p>\r\n<p dir="ltr">Theo thống k&ecirc; sơ bộ, số lượng học sinh, sinh vi&ecirc;n, nghi&ecirc;n cứu sinh c&oacute; nhu cầu t&igrave;m kiếm t&agrave;i liệu phục vụ cho qu&aacute; tr&igrave;nh học tập chiếm 40% tổng d&acirc;n số Việt Nam. Điều đ&oacute; đồng nghĩa với việc ch&uacute;ng ta c&oacute; nguồn kh&aacute;ch h&agrave;ng v&ocirc; c&ugrave;ng phong ph&uacute;. &nbsp;Search c&aacute;c từ kh&oacute;a như: gi&aacute;o tr&igrave;nh&hellip;, đề t&agrave;i&hellip;, luận văn&hellip; c&aacute;c bạn sẽ thấy nhiều kết quả hiển thị từ123doc.org, miễn ph&iacute; c&oacute;, thu ph&iacute; c&oacute;. Đấy ch&iacute;nh l&agrave; cơ hội cho bạn kinh doanh kiếm tiền bằng c&aacute;ch b&aacute;n t&agrave;i liệu tr&ecirc;n 123doc.org.</p>\r\n<p dir="ltr">C&aacute;c bạn quan t&acirc;m đến tỷ lệ chi sẻ doanh số? Điều hiển nhi&ecirc;n v&igrave; ch&uacute;ng ta hợp t&aacute;c b&aacute;n h&agrave;ng n&ecirc;n điều khoản về doanh số phải cực k&igrave; r&otilde; r&agrave;ng. 123doc.org chi sẻ 70% doanh thu tr&ecirc;n gi&aacute; b&aacute;n t&agrave;i liệu cho bạn, c&oacute; thể khẳng định đ&acirc;y l&agrave; tỷ lệ cao nhất từ trước đến nay của c&aacute;c trang website b&aacute;n t&agrave;i liệu.</p>', '', '', '2016-04-17 20:42:40', 1, '2016-04-17 19:37:53'),
(9, 'quy-dinh-ve-viec-noi-dung-va-xu-phat-tai-lieu-vi-pham-tren-website-123docorg', 'Quy định về việc nội dung và xử phạt tài liệu vi phạm trên website 123doc.org', 23, 'Quy định về việc nội dung và xử phạt tài liệu vi phạm trên website 123doc.org', '<p dir="ltr"><strong>Quy định về việc nội dung v&agrave; xử phạt t&agrave;i liệu vi phạm <br /><br />tr&ecirc;n&nbsp;website 123doc.org</strong><br /><br /></p>\r\n<p dir="ltr">Điều 1: Phạm vi điều chỉnh</p>\r\n<p dir="ltr">Quy định n&agrave;y &aacute;p dụng cho t&agrave;i liệu tr&ecirc;n 123doc.org</p>\r\n<p dir="ltr">Hoat động upload đối với c&aacute;c t&agrave;i liệu được th&agrave;nh vi&ecirc;n sưu tầm, tự s&aacute;ng t&aacute;c, bi&ecirc;n soạn</p>\r\n<p dir="ltr">Điều 2: Đối tượng &aacute;p dụng</p>\r\n<p dir="ltr">Quy định n&agrave;y &aacute;p dụng đối với c&aacute;c th&agrave;nh vi&ecirc;n của 123doc.org đ&atilde; v&agrave; đang tham gia upload tr&ecirc;n website</p>\r\n<p dir="ltr">&Aacute;p dụng đối với th&agrave;nh vi&ecirc;n muốn tham gia chia sẻ kiến thức cho cộng đồng, th&agrave;nh vi&ecirc;n mong muốn kiếm tiền từ h&igrave;nh thức b&aacute;n t&agrave;i liệu.</p>\r\n<p dir="ltr">Điều 3: Tr&aacute;ch nhiệm của Ban quản trị</p>\r\n<p dir="ltr">Quy định n&agrave;y &aacute;p dụng đối với th&agrave;nh vi&ecirc;n kiểm duyệt t&agrave;i liệu, duyệt t&agrave;i liệu đ&uacute;ng, ch&iacute;nh x&aacute;c, tr&aacute;nh sai s&oacute;t</p>\r\n<p dir="ltr">&Aacute;p dụng đối với c&aacute;c th&agrave;nh vi&ecirc;n Ban quản trị c&oacute; chức năng kiểm so&aacute;t nội bộ, ra so&aacute;t lại c&aacute;c trường hợp t&agrave;i liệu đ&atilde; duyệt, t&agrave;i liệu bị duyệt sai.</p>', '', '', '2016-04-17 20:42:37', 1, '2016-04-17 19:38:11'),
(10, 'loi-khi-mua-tai-lieu-cach-xu-ly', 'Lỗi khi mua tài liệu & Cách xử lý', 24, 'Lỗi khi mua tài liệu & Cách xử lý', '<p><strong>H&ograve;m thư hỗ trợ của 123doc l&agrave; </strong><a href="mailto:info@123doc.org"><strong>info@123doc.org</strong></a><strong>. Sự cố m&agrave; bạn gặp phải sẽ được giải quyết trong v&ograve;ng 24h kể từ khi bạn gửi mail b&aacute;o lỗi </strong><em><span style="font-weight: 400;">(kh&ocirc;ng t&iacute;nh thứ 7, CN v&agrave; c&aacute;c ng&agrave;y Lễ, Tết)</span></em></p>\r\n<p><strong>&nbsp;</strong></p>\r\n<h3><strong>1. Lỗi khi nạp thẻ:</strong></h3>\r\n<p><strong>PIN Field phải l&agrave; 1 con số!</strong></p>\r\n<p><span style="font-weight: 400;">Nếu khi nạp tiền bạn gặp b&aacute;o lỗi thế n&agrave;y, vui l&ograve;ng kiểm tra lại m&atilde; số thẻ c&agrave;o đ&atilde; nạp. M&atilde; PIN l&agrave; phần m&atilde; số dưới lớp giấy bạc, để nạp v&agrave;o 123doc.org bạn cần nhập liền mạch m&atilde; số n&agrave;y, kh&ocirc;ng khoảng c&aacute;ch, kh&ocirc;ng k&yacute; tự n&agrave;o kh&aacute;c.</span></p>', '', '', '2016-04-17 20:42:22', 1, '2016-04-17 19:38:37'),
(11, 'cau-hoi-thuong-gap-cua-nguoi-mua', 'Câu hỏi thường gặp của người mua', 24, 'Câu hỏi thường gặp của người mua', '<p dir="ltr"><strong>1. Tại sao lại c&oacute; 2 h&igrave;nh thức &ldquo;Đăng nhập để mua t&agrave;i liệu&rdquo; v&agrave; &ldquo;Nạp thẻ t&agrave;i ngay kh&ocirc;ng cần đăng nhập&rdquo;</strong></p>\r\n<p dir="ltr"><em>Quyền lợi đối với h&igrave;nh thức &ldquo;Đăng nhập để mua t&agrave;i liệu&rdquo; </em></p>\r\n<ul>\r\n<li dir="ltr">\r\n<p dir="ltr">Bạn c&oacute; quyền lưu lại số dư t&agrave;i khoản để mua tiếp c&aacute;c t&agrave;i liệu c&oacute; ph&iacute; kh&aacute;c</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">T&agrave;i khoản n&agrave;y kh&ocirc;ng c&oacute; giới hạn ng&agrave;y sử dụng</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Bạn c&oacute; thể tải c&aacute;c t&agrave;i liệu miễn ph&iacute; (t&agrave;i liệu b&ecirc;n cạnh n&uacute;t tải xuống kh&ocirc;ng c&oacute; gi&aacute; tiền) của hệ thống 123doc.org</p>\r\n</li>\r\n</ul>\r\n<p dir="ltr"><em>Quyền lợi đối với h&igrave;nh thức &ldquo;Nạp thẻ tải ngay kh&ocirc;ng cần đăng nhập&rdquo;</em></p>\r\n<ul>\r\n<li dir="ltr">\r\n<p dir="ltr">Bạn c&oacute; thể tải t&agrave;i liệu ngay m&agrave; kh&ocirc;ng cần đăng nhập hay đăng k&yacute; th&agrave;nh vi&ecirc;n tr&ecirc;n hệ thống 123doc,org</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Chỉ c&oacute; thể tải 1 t&agrave;i liệu c&oacute; ph&iacute; v&agrave; 30 t&agrave;i liệu miễn ph&iacute; (t&agrave;i liệu b&ecirc;n cạnh n&uacute;t tải xuống kh&ocirc;ng c&oacute; gi&aacute; tiền) của hệ thống 123doc.org</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Thẻ c&agrave;o c&oacute; gi&aacute; trị sử dụng trong v&ograve;ng 24h kể từ sau khi nạp</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Kh&ocirc;ng lưu lại số dư t&agrave;i khoản để mua t&agrave;i liệu tiếp theo</p>\r\n</li>\r\n</ul>', '', '', '2016-04-17 20:42:20', 1, '2016-04-17 19:38:57'),
(12, 'thoa-thuan-su-dung', 'Thỏa thuận sử dụng', 24, 'Thỏa thuận sử dụng', '<p><strong>Thỏa thuận sử dụng</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div><em><strong>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><strong>CHẤP NHẬN C&Aacute;C ĐIỀU KHOẢN THỎA THUẬN</strong></em></div>\r\n<div>&nbsp; &nbsp; &nbsp; Ch&agrave;o mừng bạn đến với 123doc.vn! Ch&uacute;ng t&ocirc;i cung cấp Dịch Vụ (như được m&ocirc; tả dưới đ&acirc;y) cho bạn, t&ugrave;y thuộc v&agrave;o c&aacute;c &ldquo;<strong>Điều Khoản Thỏa Thuận về Sử Dụng Dịch Vụ</strong>&rdquo; sau đ&acirc;y (sau đ&acirc;y được gọi tắt l&agrave; "ĐKTTSDDV"). Tại từng thời điểm, ch&uacute;ng t&ocirc;i c&oacute; thể cập nhật ĐKTTSDDV theo quyết định của m&igrave;nh m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho bạn. Bạn đồng &yacute; rằng nếu bạn tiếp tục sử dụng Dịch Vụ sau khi ĐKTTSDDV được cập nhật, việc đ&oacute; c&oacute; nghĩa l&agrave; bạn đ&atilde; chấp nhận v&agrave; đồng &yacute; tu&acirc;n theo bản ĐKTTSDDV đ&atilde; được cập nhật. Bạn c&oacute; thể xem bản ĐKTTSDDV mới nhất v&agrave;o bất cứ thời điểm n&agrave;o tại đ&acirc;y.</div>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div>Ngo&agrave;i ra, khi sử dụng c&aacute;c Dịch Vụ cụ thể thuộc sở hữu hoặc điều h&agrave;nh bởi 123doc.vn, bạn v&agrave; 123doc.vn tại từng thời điểm sẽ phải theo đ&uacute;ngc&aacute;c chỉ dẫn được ni&ecirc;m yết hoặc c&aacute;c quy định &aacute;p dụng cho c&aacute;c dịch vụ đ&oacute; c&oacute; thể được ni&ecirc;m yết theo từng thời điểm. Tất cả c&aacute;c chỉ dẫn hoặc quy định đ&oacute; được đưa v&agrave;o bản ĐKTTSDDV n&agrave;y dưới dạng tham chiếu. Trong đa số c&aacute;c trường hợp, c&aacute;c chỉ dẫn v&agrave; quy định l&agrave; cụ thể cho từng phần ri&ecirc;ng biệt của Dịch Vụ v&agrave; sẽ gi&uacute;p bạn &aacute;p dụng ĐKTTSDDV cho phần ri&ecirc;ng biệt đ&oacute;, nhưng trong trường hợp c&oacute; sự kh&ocirc;ng thống nhất giữa ĐKTTSDDV với bất kỳ quy định hoặc chỉ dẫn n&agrave;o, bản ĐKTTSDDV sẽ c&oacute; hiệu lực &aacute;p dụng.</div>', '', '', '2016-04-17 20:42:17', 1, '2016-04-17 19:39:12'),
(13, 'dieu-khoan-nguoi-ban-dam-bao', 'Điều khoản Người bán đảm bảo', 24, 'Điều khoản Người bán đảm bảo', '<div>\r\n<div><strong>Điều khoản Người b&aacute;n đảm bảo</strong></div>\r\n<div>&nbsp;</div>\r\n<div><strong><em>1.Quy định Người b&aacute;n đảm bảo</em></strong></div>\r\n</div>\r\n<div>\r\n<div>-Cung cấp đầy đủ, ch&iacute;nh x&aacute;c th&ocirc;ng tin trong bản &ldquo;X&aacute;c thực th&ocirc;ng tin c&aacute; nh&acirc;n&rdquo;</div>\r\n<div>\r\n<div><img src="http://media.store123doc.com:8080/images/news/20130514090532_18560.png" alt="" border="0" /></div>\r\n<div><span style="font-family: Arial;">&nbsp;</span></div>\r\n</div>\r\n</div>\r\n<div>-Điền đầy đủ, ch&iacute;nh x&aacute;c th&ocirc;ng tin của t&agrave;i liệu đăng b&aacute;n (<em>theo Hướng dẫn người d&ugrave;ng B&aacute;n t&agrave;i liệu</em>)</div>\r\n<div>-T&agrave;i liệu đăng b&aacute;n phải đảm bảo đ&uacute;ng quy định trong điều khoản Thỏa thuận sử dụng dịch vụ</div>\r\n<div>-Nếu c&oacute; bất cứ tranh chấp ph&aacute;t sinh về vấn đề Bản quyền t&agrave;i liệu, bằng c&aacute;ch n&agrave;o đ&oacute; bạn phải chứng minh được bạn l&agrave; chủ sở hữu thực sự của t&agrave;i liệu đ&oacute;. Nếu kh&ocirc;ng bạn sẽ kh&ocirc;ng được nhận doanh thu từ t&agrave;i liệu.</div>\r\n<div>\r\n<div>-Trong trường hợp c&oacute; 2 (hai) t&agrave;i liệu tr&ugrave;ng nhau được upload v&agrave; đăng b&aacute;n tr&ecirc;n 123doc.vn, v&agrave; kh&ocirc;ng c&oacute; tranh chấp ph&aacute;t sinh về vấn đề Bản quyền t&agrave;i liệu, ch&uacute;ng t&ocirc;i sẽ ưu ti&ecirc;n người d&ugrave;ng đầu ti&ecirc;n upload t&agrave;i liệu đ&oacute; l&ecirc;n 123doc.vn</div>\r\n</div>', '', '', '2016-04-17 20:42:15', 1, '2016-04-17 19:39:33'),
(14, 'chia-se-kiem-tien-tu-thanh-vien-kira', 'Chia sẻ kiếm tiền từ thành viên Kira', 25, 'Chia sẻ kiếm tiền từ thành viên Kira', '<div><strong>M&igrave;nh l&agrave; Kira&nbsp;<br /><br /></strong></div>\r\n<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;M&igrave;nh l&agrave; th&agrave;nh vi&ecirc;n đầu ti&ecirc;n kiếm được 200 triệu tr&ecirc;n website 123doc.org. &nbsp;H&ocirc;m nay m&igrave;nh muốn chia sẻ với c&aacute;c bạn một số kinh nghiệm b&aacute;n t&agrave;i liệu tr&ecirc;n 123doc.org của m&igrave;nh.<br /><br /></div>\r\n<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;M&igrave;nh l&agrave;m về lĩnh vực t&agrave;i liệu hơn 5 năm v&agrave; cũng từng tạo ra website ri&ecirc;ng nhưng vấn đề bảo mật của m&igrave;nh kh&ocirc;ng được tốt n&ecirc;n t&igrave;m đối t&aacute;c c&ugrave;ng l&agrave;m. Sau nhiều lần t&igrave;m hiểu v&agrave; so s&aacute;nh giữa c&aacute;c website kilobook, doko, tailieu.vn nhưng m&igrave;nh lựa chọn 123doc.org. M&igrave;nh lựa chọn 123doc.org v&igrave; một số l&yacute; do:&nbsp;<br /><br /></div>\r\n<blockquote>\r\n<div>-Tỷ lệ chiết khấu cao: khi b&aacute;n t&agrave;i liệu m&igrave;nh được hưởng 70% doanh thu (đ&acirc;y l&agrave; tỷ lệ doanh thu cao nhất m&igrave;nh từng thấy ở c&aacute;c website th&ocirc;ng thưởng chỉ tầm 50% l&agrave; cao). &nbsp;</div>\r\n</blockquote>\r\n<blockquote>\r\n<div>VD: kh&aacute;ch &nbsp;h&agrave;ng chi trả 100.000VND th&igrave; bạn nhận được 70% gi&aacute; trị = 70.000VNĐ</div>\r\n</blockquote>\r\n<blockquote>\r\n<div>-Upload t&agrave;i liệu đơn giản v&agrave; dễ d&ugrave;ng, m&igrave;nh từng upload khoảng hơn 4000 t&agrave;i liệu/ ng&agrave;y.&nbsp;</div>\r\n<div>-C&oacute; nhiều chương tr&igrave;nh cho c&aacute;c th&agrave;nh vi&ecirc;n kiếm tiền như tiền kiếm từ lượt view t&agrave;i liệu, share t&agrave;i liệu &amp; upload t&agrave;i liệu l&ecirc;n cũng c&oacute; tiền (C&aacute;i n&agrave;y đặc biệt rất hay, mỗi t&agrave;i liệu upload l&ecirc;n được 100VNĐ). Ban quản trị kiếm được tiền từ nguồn n&agrave;o th&igrave; lu&ocirc;n chia sẻ với th&agrave;nh vi&ecirc;n để c&ugrave;ng kiếm tiền (V&iacute; dụ lượt share &amp; view l&agrave; chia % từ doanh thu quảng c&aacute;o)</div>\r\n<div>-Support rất nhiệt t&igrave;nh v&agrave; chuy&ecirc;n nghiệp. Đ&acirc;y l&agrave; khoản m&igrave;nh cảm thấy hơn hẳn c&aacute;c website m&agrave; m&igrave;nh từng tham gia</div>\r\n<div>-M&igrave;nh c&oacute; thể y&ecirc;u cầu thanh to&aacute;n 1 tuần/ 1 lần, thanh to&aacute;n minh bạch r&otilde; r&agrave;ng.</div>\r\n<div>-Chức năng Upload k&eacute;o thả tiện lợi, c&oacute; thể upload h&agrave;ng chục, h&agrave;ng trăm t&agrave;i liệu 1 lần, v&agrave; chức năng bi&ecirc;n tập nhanh t&agrave;i liệu 1 lần.</div>\r\n<div>-BQT website lu&ocirc;n ghi nhận sự g&oacute;p &yacute; của th&agrave;nh vi&ecirc;n v&agrave; c&oacute; sự điều chỉnh hợp l&yacute; nhằm n&acirc;ng cao chất lượng v&agrave; doanh thu của website</div>\r\n</blockquote>', '', '', '2016-04-17 20:42:13', 1, '2016-04-17 19:40:00'),
(15, '123doc-thong-bao-nghi-tet-binh-than-2016', '123doc Thông báo nghỉ Tết Bính Thân 2016', 26, '123doc Thông báo nghỉ Tết Bính Thân 2016', '<p dir="ltr">BQT 123doc.org xin th&ocirc;ng b&aacute;o!</p>\r\n<p dir="ltr">Team 123doc sẽ nghỉ Tết B&iacute;nh Th&acirc;n từ ng&agrave;y 06/02/2016 đến hết ng&agrave;y 14/02/2016. Trong thời gian n&agrave;y c&aacute;c bạn vẫn c&oacute; thể upload, download, nạp tiền b&igrave;nh thường, website cũng vậy. Tuy nhi&ecirc;n nếu c&oacute; bất kỳ sự cố n&agrave;o xảy ra, team 123doc xin ph&eacute;p l&ugrave;i đến sau khi kết th&uacute;c kỳ nghỉ Tết để giải quyết. BQT sẽ cố gắng duyệt hết c&aacute;c t&agrave;i liệu được upload trước ng&agrave;y 06/02/2016. Những t&agrave;i liệu được upload sau ng&agrave;y 06/02 sẽ được duyệt kể từ ng&agrave;y 15/02/2016.</p>\r\n<p dir="ltr">Mong c&aacute;c bạn nắm được lịch l&agrave;m việc n&agrave;y. Ch&uacute;c c&aacute;c bạn c&oacute; một kỳ nghỉ lễ &yacute; nghĩa b&ecirc;n gia đ&igrave;nh v&agrave; người th&acirc;n!</p>', '', '', '2016-04-17 20:42:10', 1, '2016-04-17 19:40:21'),
(16, 'tong-ket-nam-2015-cua-123doc', 'Tổng kết năm 2015 của 123doc', 26, 'Tổng kết năm 2015 của 123doc', '<p dir="ltr">Một năm nữa lại qua, một năm mới vừa đến. Ch&uacute;ng ta đ&atilde; trải qua 3 m&ugrave;a xu&acirc;n c&ugrave;ng với 123doc.org, v&agrave; sự đổi thay sau 3 năm nh&igrave;n lại quả thật kh&ocirc;ng hề nhỏ phải kh&ocirc;ng n&agrave;o?</p>\r\n<p>&nbsp;</p>\r\n<p dir="ltr">Năm nay, th&ecirc;m v&agrave;o kh&ocirc;ng kh&iacute; xu&acirc;n sang rộn r&agrave;ng n&agrave;y, 123doc muốn mang đến cho c&aacute;c bạn một niềm vui nho nhỏ. Đ&acirc;y cũng l&agrave; lời cảm ơn của 123doc d&agrave;nh tới những th&agrave;nh vi&ecirc;n hoạt động t&iacute;ch cực tr&ecirc;n website suốt một năm qua. Những m&oacute;n qu&agrave; của 123doc gi&aacute; trị kh&ocirc;ng lớn, nhưng n&oacute; chứa đựng t&igrave;nh cảm của to&agrave;n bộ team 123doc đối với c&aacute;c bạn. C&ugrave;ng kh&aacute;m ph&aacute; những m&oacute;n qu&agrave; đ&oacute; nh&eacute;.</p>', '', '', '2016-04-17 20:42:08', 1, '2016-04-17 19:40:35'),
(17, 'moi-lan-share-moi-lan-bat-ngo', 'Mỗi lần share, Mỗi lần bất ngờ', 26, 'Mỗi lần share, Mỗi lần bất ngờ', '<p><strong>Mỗi lần share, Mỗi lần bất ngờ</strong><br /><br /></p>\r\n<p>Nhận thấy chương tr&igrave;nh đại l&yacute; c&oacute; nhiều bất hợp l&yacute;: kh&oacute; tham gia, xuất hiện nhiều link khi phải chia sẻ. BQT đ&atilde; quyết định gộp chương tr&igrave;nh share &amp; đại l&yacute; l&agrave;m một để mang lại nhiều lợi &iacute;ch nhất cho th&agrave;nh vi&ecirc;n tham gia kiếm tiền. Theo đ&oacute; chỉ c&ograve;n lại ch&iacute;nh s&aacute;ch Share link kiếm tiền, nếu t&agrave;i liệu bạn share được c&aacute;c th&agrave;nh vi&ecirc;n mua, bạn sẽ được 10% v&agrave;o t&agrave;i khoản. Cụ thể:<br /><br /></p>\r\n<ol>\r\n<li><strong>Lợi &iacute;ch khi tham gia</strong></li>\r\n</ol>\r\n<ul>\r\n<li>&nbsp;Hưởng tới 10% gi&aacute; trị t&agrave;i liệu b&aacute;n / mỗi lượt mua (Từ ng&agrave;y 16/4 -&gt; 30/4/2014 đại l&yacute; sẽ được nhận l&ecirc;n đến 15%). VD: T&agrave;i liệu m&agrave; bạn giới thiệu c&oacute; gi&aacute; 50.000 VNĐ, th&igrave; bạn sẽ được 5.000 VNĐ, 10 lần mua, bạn được 50.000 VNĐ (Người b&aacute;n 70%, Bạn: 10%, 123Doc: 20%)</li>\r\n<li>D&ugrave; cho link chia sẻ kh&ocirc;ng được mua, bạn vẫn c&oacute; được 5 VNĐ / 1 click v&agrave;o t&agrave;i khoản</li>\r\n<li>Lựa chọn hơn 1.300.000 t&agrave;i liệu phong ph&uacute;, đầy đủ, chất lượng tr&ecirc;n 123doc.org</li>\r\n</ul>', '', '', '2016-04-17 20:41:10', 1, '2016-04-17 19:40:55'),
(18, 'upload-tai-lieu-luan-van-bao-cao-giup-do-sinh-vien', 'Upload tài liệu luận văn báo cáo, giúp đỡ sinh viên', 26, 'Upload tài liệu luận văn báo cáo, giúp đỡ sinh viên', '<p dir="ltr">Nhằm mang lại một s&acirc;n chơi cho c&aacute;c th&agrave;nh vi&ecirc;n, tạo hiệu ứng s&ocirc;i nổi cho trang web &amp; mang lại lợi &iacute;ch nhiều hơn cho c&aacute;c th&agrave;nh vi&ecirc;n. Từ th&aacute;ng 10/2014,123doc.org sẽ tổ chức nhiều hơn, nhanh hơn c&aacute;c event. Event đầu ti&ecirc;n xin giới thiệu với mọi người.</p>\r\n<p dir="ltr">Upload t&agrave;i liệu luận văn b&aacute;o c&aacute;o</p>\r\n<p dir="ltr">gi&uacute;p đỡ sinh vi&ecirc;n</p>\r\n<p dir="ltr">Thời gian tổ chức</p>\r\n<ul>\r\n<li dir="ltr">\r\n<p dir="ltr">Thời gian diễn ra từ 0h0p 03/10 - 24h00 10/10/2014</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Thời gian xem x&eacute;t &amp; trao giải: Ng&agrave;y 13/10/2014</p>\r\n</li>\r\n</ul>\r\n<p dir="ltr">T&agrave;i liệu đủ điều kiện</p>\r\n<ul>\r\n<li dir="ltr">\r\n<p dir="ltr">T&agrave;i liệu thuộc danh mục luận văn b&aacute;o c&aacute;o</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">T&agrave;i liệu được duyệt</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">T&agrave;i liệu &gt;= 10 trang</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Giải nhất: &gt;=500 t&agrave;i liệu</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Giải nh&igrave;: &gt;=300 t&agrave;i liệu</p>\r\n</li>\r\n<li dir="ltr">\r\n<p dir="ltr">Giải ba: &gt;=100 t&agrave;i liệu</p>\r\n</li>\r\n</ul>', '', '', '2016-04-17 20:39:45', 1, '2016-04-17 20:34:42'),
(19, 'upload-tai-lieu-danh-muc-giao-duc-dao-tao', 'Upload tài liệu danh mục "Giáo dục- Đào tạo"', 26, 'Upload tài liệu danh mục "Giáo dục- Đào tạo"', '<p dir="ltr">Lu&ocirc;n hướng tới l&agrave; website dẫn đầu chia sẻ v&agrave; mua b&aacute;n t&agrave;i liệu h&agrave;ng đầu Việt Nam. T&aacute;c phong chuy&ecirc;n nghiệp, ho&agrave;n hảo, đề cao t&iacute;nh tr&aacute;ch nhiệm đối với từng người d&ugrave;ng. Mục ti&ecirc;u h&agrave;ng đầu của 123doc.org trở th&agrave;nh thư viện t&agrave;i liệu online lớn nhất Việt Nam, cung cấp những t&agrave;i liệu độc kh&ocirc;ng thể t&igrave;m thấy tr&ecirc;n thị trường ngoại trừ 123doc.org.</p>\r\n<p dir="ltr">Từ ng&agrave;y 5/7 đến 15/7/2015, 123doc quyết định mở event:</p>', '', '', '2016-04-17 20:40:18', 1, '2016-04-17 20:40:18');

-- --------------------------------------------------------

--
-- Table structure for table `doc_config`
--

CREATE TABLE `doc_config` (
  `ID` int(11) NOT NULL,
  `label` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value_vi` text COLLATE utf8_unicode_ci NOT NULL,
  `value_en` text COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci NOT NULL,
  `order` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_config`
--

INSERT INTO `doc_config` (`ID`, `label`, `name`, `value_vi`, `value_en`, `type`, `group`, `attributes`, `order`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Nội dung header', 'contentHeader', '<p>dsa</p>', '', 'editor', '', '', 10, 1, '2016-03-25 16:20:23', '0000-00-00 00:00:00'),
(2, 'Logo', 'logo', '2.jpg', '', 'file', '', '', 2, 1, '2016-04-13 17:22:31', '0000-00-00 00:00:00'),
(3, 'Banner', 'banner', 'gotit-headline-photo.jpg', '', 'file', '', '', 3, 1, '2016-04-13 17:22:31', '0000-00-00 00:00:00'),
(4, 'Nội dung footer', 'contentFooter', '<p>dsa<img src="http://laravel_docs.local/uploads/filemanager/654125f4-010d-476e-8a89-b2fb0fc1d996.jpg" alt="" /></p>', '', 'editor', '', '', 4, 1, '2016-03-25 16:26:33', '0000-00-00 00:00:00'),
(5, 'Hotline', 'hotline', 'dff', '', 'text', '', '{"placeholder":"Đường dây nóng"}', 5, 1, '2016-03-25 17:13:10', '0000-00-00 00:00:00'),
(6, 'Tiêu đề trang', 'meta_title', '4', '', 'textarea', '', '', 3, 1, '2016-03-27 07:52:14', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `doc_customers`
--

CREATE TABLE `doc_customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `id_card` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `phone` char(11) COLLATE utf8_unicode_ci NOT NULL,
  `gender` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `birth_day` date NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `verify_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_customers`
--

INSERT INTO `doc_customers` (`id`, `name`, `email`, `id_card`, `phone`, `gender`, `password`, `birth_day`, `address`, `role`, `status`, `verify_code`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hà Trọng Nguyên', 'nguyen1@gmail.com', '', '0555555555', 'nam', '$2y$10$H2bTD2ycHyciVhlijCkTbu1T0Ii9JdTsK.YLrmd4cjKT.ThGbGIyO', '2000-11-30', 'Hà Nội', '1', '1', '', '37t9I9U6lI4zc0izJEKODfnCClxAeaEbJCdJedUovK3WYbCLvVUTQjH55b2m', '2016-03-31 09:25:52', '2016-04-17 20:25:36');

-- --------------------------------------------------------

--
-- Table structure for table `doc_customer_finance`
--

CREATE TABLE `doc_customer_finance` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `income` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_customer_finance`
--

INSERT INTO `doc_customer_finance` (`id`, `user_id`, `income`, `balance`, `created_at`, `updated_at`) VALUES
(1, 5, 0, 200050, '2016-03-30 06:29:07', '2016-03-30 06:45:46'),
(2, 4, 0, 30, '2016-03-30 06:48:09', '2016-03-30 06:48:09'),
(3, 1, 0, 50000, '2016-03-30 08:09:52', '2016-03-30 08:09:52');

-- --------------------------------------------------------

--
-- Table structure for table `doc_document`
--

CREATE TABLE `doc_document` (
  `id` int(10) UNSIGNED NOT NULL,
  `author` int(11) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `format` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `thumbnail` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `page_viewed` smallint(6) NOT NULL,
  `total_page` smallint(5) DEFAULT NULL,
  `link_file` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tax_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_document`
--

INSERT INTO `doc_document` (`id`, `author`, `slug`, `title`, `price`, `format`, `thumbnail`, `page_viewed`, `total_page`, `link_file`, `tax_id`, `created_at`, `updated_at`) VALUES
(1, 1, '', 'Đề thi tốt nghiệp 2016', 5000, 'docx', '', 0, 2, '12802821_914519861999377_558210973457457378_n.jpg', 7, '2016-03-23 17:00:00', '2016-03-31 09:23:55'),
(2, 1, '', 'sadsa', 200, 'pdf', '', 0, 3, 'Capture.PNG', 7, '2016-03-31 10:00:59', '2016-03-31 10:00:59'),
(3, 1, '', 'sadsa', 200, 'pdf', '', 0, 4, 'Capture.PNG', 7, '2016-03-31 10:01:19', '2016-04-03 06:55:00'),
(4, 1, '', 'sadsa', 200, 'doc', '', 0, 5, 'Capture.PNG', 7, '2016-03-31 10:01:28', '2016-03-31 10:01:28'),
(5, 1, '', 'Toán lớp 1', 2000, 'sql', '', 0, 7, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:40:01', '2016-04-10 11:40:01'),
(6, 1, '', 'Ngữ văn', 2500, 'sql', '', 0, 5, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:40:46', '2016-04-10 11:40:46'),
(7, 2, '', 'Khoa học 1', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(8, 2, '', 'Khoa học 2', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(9, 2, '', 'Khoa học 3', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(10, 2, '', 'Khoa học 4', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(11, 2, '', 'Khoa học 5', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(12, 2, '', 'Khoa học 6', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(13, 2, '', 'Khoa học 7', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(14, 2, '', 'Khoa học 8', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(15, 2, '', 'Khoa học 9', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(16, 2, '', 'Khoa học 10', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(17, 2, '', 'Khoa học 11', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(18, 2, '', 'Khoa học 12', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(19, 2, '', 'Khoa học 13', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(20, 2, '', 'Khoa học 14', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(21, 2, '', 'Khoa học 15', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(22, 2, '', 'Khoa học 16', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(23, 2, '', 'Khoa học 17', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(24, 2, '', 'Khoa học 18', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(25, 2, '', 'Khoa học 19', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(26, 2, '', 'Khoa học 20', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(27, 2, '', 'Khoa học 21', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(28, 2, '', 'Khoa học 22', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(29, 2, '', 'Khoa học 23', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(30, 2, '', 'Khoa học 24', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(31, 2, '', 'Khoa học 25', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(32, 2, '', 'Khoa học 26', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(33, 2, '', 'Khoa học 27', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(34, 2, '', 'Khoa học 28', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(35, 2, '', 'Khoa học 29', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(36, 2, '', 'Khoa học 30', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(37, 2, '', 'Khoa học 31', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(38, 2, '', 'Khoa học 32', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(39, 2, '', 'Khoa học 33', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(40, 2, '', 'Khoa học 34', 222, 'sql', '', 0, 8, 'd6bde3deb4848e5d790b8b6d76c23ff7.sql', 6, '2016-04-10 11:41:22', '2016-04-10 11:41:22'),
(42, 0, 'bao-cao-sang-ngay-15-04chinh-42', 'Báo cáo sáng ngày 15-04Chinh', 0, 'docx', '', 0, NULL, 'uploads/documents/document-1460703018.docx', 0, '2016-04-14 23:50:18', '2016-04-14 23:50:18'),
(43, 0, 'search-engine-optimization-43', 'Search Engine Optimization', 0, 'docx', '', 0, NULL, 'uploads/documents/document-1461227263.docx', 0, '2016-04-21 01:27:43', '2016-04-21 01:27:43');

-- --------------------------------------------------------

--
-- Table structure for table `doc_doc_keywords`
--

CREATE TABLE `doc_doc_keywords` (
  `id` int(10) UNSIGNED NOT NULL,
  `doc_id` int(11) NOT NULL,
  `key_word` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_doc_keywords`
--

INSERT INTO `doc_doc_keywords` (`id`, `doc_id`, `key_word`, `created_at`, `updated_at`) VALUES
(31, 1, 'Đề thi', '2016-03-31 09:23:55', '2016-03-31 09:23:55'),
(32, 1, 'Đề thi toán', '2016-03-31 09:23:55', '2016-03-31 09:23:55'),
(33, 3, 'adsad', '2016-04-03 06:55:00', '2016-04-03 06:55:00'),
(34, 3, 'adsada', '2016-04-03 06:55:00', '2016-04-03 06:55:00'),
(35, 5, 'Bài tập tính từ', '2016-04-10 08:57:03', '2016-04-10 08:57:03'),
(36, 5, 'Bài tập tính từ 2', '2016-04-10 08:57:03', '2016-04-10 08:57:03'),
(37, 5, 'Bài tập tính từ 3', '2016-04-10 08:57:03', '2016-04-10 08:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `doc_doc_meta`
--

CREATE TABLE `doc_doc_meta` (
  `id` int(10) UNSIGNED NOT NULL,
  `doc_id` int(11) NOT NULL,
  `num_viewed` int(11) NOT NULL,
  `num_downloaded` int(11) NOT NULL,
  `date_sold` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_doc_meta`
--

INSERT INTO `doc_doc_meta` (`id`, `doc_id`, `num_viewed`, `num_downloaded`, `date_sold`, `created_at`, `updated_at`) VALUES
(1, 1, 15, 0, '2016-04-10 18:54:20', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 2, 12, 24, '2016-04-10 18:54:23', NULL, NULL),
(3, 3, 13, 56, '2016-04-10 18:54:26', NULL, NULL),
(4, 4, 15, 44, '2016-04-10 18:54:25', NULL, NULL),
(5, 5, 11, 77, '2016-04-10 18:54:27', NULL, NULL),
(6, 6, 12, 88, '2016-04-10 18:54:28', NULL, NULL),
(7, 7, 15, 23, '2016-04-13 16:25:37', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 8, 16, 323, '2016-04-13 16:25:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 9, 11, 23, '2016-04-13 16:25:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 10, 3, 2, '2016-04-13 16:25:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 11, 152, 233, '2016-04-13 16:25:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 12, 15243, 38, '2016-04-13 16:25:52', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 13, 15, 3, '2016-04-13 16:25:38', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 14, 15324, 3, '2016-04-13 16:25:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 15, 42, 24, '2016-04-13 16:25:41', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 16, 15, 3, '2016-04-13 16:25:36', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 17, 15, 23383, '2016-04-13 16:25:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 18, 32, 783, '2016-04-13 16:25:50', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 19, 23, 3, '2016-04-13 16:25:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 20, 1532, 53, '2016-04-13 16:25:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 21, 154, 535, '2016-04-13 16:25:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 22, 1532, 2332, '2016-04-13 16:25:38', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 23, 1523, 373, '2016-04-13 16:25:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 24, 1532, 387, '2016-04-13 16:25:48', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 25, 15, 35737, '2016-04-13 16:25:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 26, 1523, 235, '2016-04-13 16:25:44', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 27, 15232, 737, '2016-04-13 16:25:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 28, 1532, 3, '2016-04-13 16:25:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 29, 153, 37, '2016-04-13 16:25:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 30, 152332, 353, '2016-04-13 16:25:47', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 31, 1523, 37, '2016-04-13 16:25:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 32, 153768, 678, '2016-04-13 16:26:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 33, 15786, 686, '2016-04-13 16:26:04', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 34, 15678, 67, '2016-04-13 16:26:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 35, 15687, 87, '2016-04-13 16:26:04', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 36, 6, 78, '2016-04-13 16:26:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 37, 156, 6678, '2016-04-13 16:26:04', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 38, 7887, 687, '2016-04-13 16:26:02', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 39, 156, 68, '2016-04-13 16:26:04', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 40, 157878, 6877, '2016-04-13 16:26:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `doc_message`
--

CREATE TABLE `doc_message` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doc_migrations`
--

CREATE TABLE `doc_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_migrations`
--

INSERT INTO `doc_migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2016_03_21_155001_create_taxonomy_table', 1),
('2016_03_21_155156_create_document_table', 1),
('2016_03_21_155207_create_doc_keywords_table', 1),
('2016_03_21_155233_create_doc_meta_table', 1),
('2016_03_21_155504_create_user_finance_table', 1),
('2016_03_21_155726_create_trading_history_table', 1),
('2016_03_21_155749_create_message_table', 1),
('2014_10_12_000000_create_users_table', 1),
('2016_03_21_155001_create_taxonomy_table', 1),
('2016_03_21_155156_create_document_table', 1),
('2016_03_21_155207_create_doc_keywords_table', 1),
('2016_03_21_155233_create_doc_meta_table', 1),
('2016_03_21_155504_create_user_finance_table', 1),
('2016_03_21_155726_create_trading_history_table', 1),
('2016_03_21_155749_create_message_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doc_nav_backend`
--

CREATE TABLE `doc_nav_backend` (
  `ID` int(11) NOT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doc_nav_backend`
--

INSERT INTO `doc_nav_backend` (`ID`, `route`, `title`, `link`, `icon`, `parent`, `position`, `status`) VALUES
(1, 'Backend::config', 'Cấu hình website', 'backend/config/', 'fa-cogs', 0, 2, 1),
(2, 'Backend::transaction', 'Quản lý giao dịch', 'backend/transaction/', 'fa-shopping-cart ', 0, 3, 1),
(4, 'Backend::customers', 'Quản lý người dùng', 'backend/customers/', 'fa-users', 0, 5, 1),
(5, 'Backend::dashboard', 'Trang tổng quan', 'backend/dashboard', 'fa-tachometer', 0, 1, 1),
(6, 'Backend::taxonomy', 'Quản lý danh mục', 'backend/taxonomy', 'fa-indent', 0, 10, 1),
(7, 'Backend::document', 'Quản lý tài liệu', 'backend/document', 'fa-file-text', 0, 20, 1),
(8, 'Backend::articles', 'Quản lý bài viết', '/backend/articles/', 'fa-file-text-o', 0, 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `doc_taxonomy`
--

CREATE TABLE `doc_taxonomy` (
  `id` int(10) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tax_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `parent` smallint(6) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_taxonomy`
--

INSERT INTO `doc_taxonomy` (`id`, `slug`, `tax_name`, `description`, `parent`, `type`, `created_at`, `updated_at`) VALUES
(1, 'giao-duc-dao-tao', 'Giáo dục - Đào tạo', '', 0, '', '2016-04-02 01:28:36', '2016-04-02 01:28:36'),
(2, 'mam-non', 'Mầm non', '', 1, '', '2016-04-02 01:29:11', '2016-04-02 01:29:11'),
(3, 'lop-3-12-thang-tuoi', 'Lớp 3 - 12 tháng tuổi', '', 2, '', '2016-04-02 01:30:41', '2016-04-02 01:30:41'),
(4, 'lop-12-24-thang-tuoi', 'Lớp 12 - 24 tháng tuổi', '', 2, '', '2016-04-02 01:30:53', '2016-04-02 01:30:53'),
(5, 'tieu-hoc', 'Tiểu học', '', 1, '', '2016-04-02 01:31:55', '2016-04-02 01:31:55'),
(6, 'lop-1', 'Lớp 1', '', 5, '', '2016-04-02 01:32:45', '2016-04-02 01:32:45'),
(7, 'lop-2', 'Lớp 2', '', 5, '', '2016-04-02 01:33:04', '2016-04-02 01:33:04'),
(8, 'trung-hoc-co-so', 'Trung học cơ sở', '', 1, '', '2016-04-02 01:33:39', '2016-04-02 01:33:39'),
(9, 'lop-6', 'Lớp 6', '', 8, '', '2016-04-02 01:33:58', '2016-04-02 01:33:58'),
(10, 'ky-nang-mem', 'Kỹ năng mềm', '', 0, '', '2016-04-02 01:34:24', '2016-04-02 01:34:24'),
(11, 'kinh-doanh-tiep-thi', 'Kinh doanh - Tiếp thị', '', 0, '', '2016-04-02 01:37:40', '2016-04-02 01:37:40'),
(12, 'kinh-te-quan-ly', 'Kinh tế - Quản lý', '', 0, '', '2016-04-02 01:38:06', '2016-04-02 01:38:06'),
(13, 'tai-chinh-ngan-hang', 'Tài chính - Ngân hàng', '', 0, '', '2016-04-02 01:38:24', '2016-04-02 01:38:24'),
(14, 'bieu-mau-van-ban', 'Biểu mẫu - Văn bản', '', 0, '', '2016-04-02 01:38:47', '2016-04-02 01:38:47'),
(15, 'cong-nghe-thong-tin', 'Công nghệ thông tin', '', 0, '', '2016-04-02 01:40:30', '2016-04-02 01:40:30'),
(16, 'ky-thuat-cong-nghe', 'Kỹ thuật - Công nghệ', '', 0, '', '2016-04-02 01:40:47', '2016-04-02 01:40:47'),
(17, 'ky-nang-lanh-dao', 'Kỹ năng lãnh đạo', '', 10, '', '2016-04-02 19:21:09', '2016-04-02 19:21:09'),
(18, 'ky-nang-quan-ly', 'Kỹ năng quản lý ', '', 10, '', '2016-04-02 19:21:21', '2016-04-02 19:21:21'),
(19, 'ky-nang-tu-duy-logic', 'Kỹ năng tư duy- logic', '', 10, '', '2016-04-02 19:21:29', '2016-04-02 19:21:29'),
(20, 'ky-nang-thuyet-trinh', 'Kỹ năng thuyết trình', '', 10, '', '2016-04-02 19:21:37', '2016-04-02 19:21:37'),
(21, 'ky-nang-giao-tiep', 'Kỹ năng giao tiếp', '', 10, '', '2016-04-02 19:21:45', '2016-04-02 19:21:45'),
(22, 'gioi-thieu', 'Giới thiệu', '', 0, 'article', '2016-04-20 17:11:45', '2016-04-20 17:11:45'),
(23, 'danh-cho-nguoi-ban', 'Dành cho người bán', '', 0, 'article', '2016-04-20 17:12:00', '2016-04-20 17:12:00'),
(24, 'danh-cho-nguoi-mua', 'Dành cho người mua', '', 0, 'article', '2016-04-20 17:12:07', '2016-04-20 17:12:07'),
(25, 'cau-chuyen-thanh-cong', 'Câu chuyện thành công', '', 0, 'article', '2016-04-20 17:12:20', '2016-04-20 17:12:20'),
(26, 'thong-bao', 'Thông báo', '', 0, 'article', '2016-04-20 17:12:29', '2016-04-20 17:12:29');

-- --------------------------------------------------------

--
-- Table structure for table `doc_trading_history`
--

CREATE TABLE `doc_trading_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `trading_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `trading_type` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `trading_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trading_status` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `trading_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `amount_money` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doc_trading_history`
--

INSERT INTO `doc_trading_history` (`id`, `trading_code`, `trading_type`, `trading_date`, `trading_status`, `trading_name`, `amount_money`, `order_id`, `owner_id`, `created_at`, `updated_at`) VALUES
(1, '21111', '1', '2016-04-20 17:00:00', '', '', 200000, 0, 1, '2016-04-20 16:37:51', '2016-04-20 16:37:51');

-- --------------------------------------------------------

--
-- Table structure for table `doc_users`
--

CREATE TABLE `doc_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `id_card` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `phone` char(11) COLLATE utf8_unicode_ci NOT NULL,
  `gender` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `birth_day` date NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `verify_code` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doc_user_finance`
--

CREATE TABLE `doc_user_finance` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `income` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doc_articles`
--
ALTER TABLE `doc_articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_config`
--
ALTER TABLE `doc_config`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `doc_customers`
--
ALTER TABLE `doc_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `doc_customer_finance`
--
ALTER TABLE `doc_customer_finance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_document`
--
ALTER TABLE `doc_document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_doc_keywords`
--
ALTER TABLE `doc_doc_keywords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_doc_meta`
--
ALTER TABLE `doc_doc_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_message`
--
ALTER TABLE `doc_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_nav_backend`
--
ALTER TABLE `doc_nav_backend`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `doc_taxonomy`
--
ALTER TABLE `doc_taxonomy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_trading_history`
--
ALTER TABLE `doc_trading_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc_users`
--
ALTER TABLE `doc_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `doc_user_finance`
--
ALTER TABLE `doc_user_finance`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doc_articles`
--
ALTER TABLE `doc_articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `doc_config`
--
ALTER TABLE `doc_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `doc_customers`
--
ALTER TABLE `doc_customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `doc_customer_finance`
--
ALTER TABLE `doc_customer_finance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `doc_document`
--
ALTER TABLE `doc_document`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `doc_doc_keywords`
--
ALTER TABLE `doc_doc_keywords`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `doc_doc_meta`
--
ALTER TABLE `doc_doc_meta`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `doc_message`
--
ALTER TABLE `doc_message`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `doc_nav_backend`
--
ALTER TABLE `doc_nav_backend`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `doc_taxonomy`
--
ALTER TABLE `doc_taxonomy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `doc_trading_history`
--
ALTER TABLE `doc_trading_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `doc_users`
--
ALTER TABLE `doc_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `doc_user_finance`
--
ALTER TABLE `doc_user_finance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
